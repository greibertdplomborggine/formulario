const db = require('./model.js');

function getAllUsers(id) {
  if (id) {

  } else {
    return db;
  }
}

async function createUser(user) {
  const docRef = db.collection('usuarios');
  return await docRef.add(user)
}

function updateUser(id, datosACambiar) {
  const userEncontrado = db.find(uid => uid.id === id ? uid : null)

  return userEncontrado.email = datosACambiar;
}

module.exports = {
  add: createUser,
  list: getAllUsers,
  update: updateUser,
}